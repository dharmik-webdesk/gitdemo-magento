<?php

namespace StripeIntegration\Payments\Model\Stripe;

class Customer extends StripeObject
{
    protected $objectSpace = 'customers';
}
