<?php

namespace StripeIntegration\Payments\Exception;

use StripeIntegration\Payments\Helper\Logger;

class SCANeededException extends \Exception
{

}
